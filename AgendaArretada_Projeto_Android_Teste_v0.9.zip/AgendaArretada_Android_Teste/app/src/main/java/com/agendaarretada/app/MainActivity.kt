package com.agendaarretada.app

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.JavascriptInterface
import android.provider.OpenableColumns
import java.io.OutputStream
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private var filePathCallback: ValueCallback<Array<Uri>>? = null
    private val fileChooserRequest = 4107
    private val saveBackupRequest = 4108
    private var pendingBackupBytes: ByteArray? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.WHITE
        window.navigationBarColor = android.graphics.Color.WHITE
        window.decorView.systemUiVisibility = android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or
            android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR

        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.addJavascriptInterface(AndroidBridge(), "AndroidBridge")
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        webView.settings.allowContentAccess = true
        webView.settings.setSupportZoom(false)
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val uri = request?.url ?: return false
                return uri.scheme == "http" || uri.scheme == "https"
            }
        }
        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                this@MainActivity.filePathCallback?.onReceiveValue(null)
                this@MainActivity.filePathCallback = filePathCallback
                val intent = fileChooserParams?.createIntent() ?: Intent(Intent.ACTION_GET_CONTENT).apply {
                    type = "*/*"
                    addCategory(Intent.CATEGORY_OPENABLE)
                }
                return try {
                    startActivityForResult(intent, fileChooserRequest)
                    true
                } catch (_: Exception) {
                    this@MainActivity.filePathCallback?.onReceiveValue(null)
                    this@MainActivity.filePathCallback = null
                    Toast.makeText(this@MainActivity, "Não foi possível abrir os arquivos.", Toast.LENGTH_SHORT).show()
                    false
                }
            }
        }
        setContentView(webView)
        webView.loadUrl("file:///android_asset/www/index.html")
    }

    private inner class AndroidBridge {
        @JavascriptInterface
        fun saveBackup(json: String, filename: String) {
            runOnUiThread {
                try {
                    if (json.isBlank() || json.trim() == "{}" || json.trim() == "null") {
                        Toast.makeText(this@MainActivity, "O backup foi gerado vazio. Nenhum arquivo foi salvo.", Toast.LENGTH_LONG).show()
                        webView.evaluateJavascript("window.onNativeBackupSaved && window.onNativeBackupSaved(false)", null)
                        return@runOnUiThread
                    }
                    pendingBackupBytes = json.toByteArray(Charsets.UTF_8)
                    val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "application/json"
                        putExtra(Intent.EXTRA_TITLE, filename)
                    }
                    startActivityForResult(intent, saveBackupRequest)
                } catch (_: Exception) {
                    pendingBackupBytes = null
                    Toast.makeText(this@MainActivity, "Não foi possível abrir a tela para salvar o backup.", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    @Deprecated("Deprecated in Android API, kept for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == fileChooserRequest) {
            val result = if (resultCode == Activity.RESULT_OK) WebChromeClient.FileChooserParams.parseResult(resultCode, data) else null
            filePathCallback?.onReceiveValue(result)
            filePathCallback = null
        } else if (requestCode == saveBackupRequest) {
            val bytes = pendingBackupBytes
            pendingBackupBytes = null
            if (resultCode == Activity.RESULT_OK && data?.data != null && bytes != null) {
                try {
                    if (bytes.isEmpty()) throw IllegalStateException("Conteúdo do backup vazio")
                    val output = contentResolver.openOutputStream(data.data!!, "w")
                        ?: throw IllegalStateException("Não foi possível abrir o destino para gravação")
                    output.use {
                        it.write(bytes)
                        it.flush()
                    }
                    Toast.makeText(this, "Backup salvo (${bytes.size} bytes). Confira o arquivo escolhido.", Toast.LENGTH_LONG).show()
                    webView.evaluateJavascript("window.onNativeBackupSaved && window.onNativeBackupSaved(true)", null)
                } catch (_: Exception) {
                    Toast.makeText(this, "Falha ao gravar o backup. Escolha outro local e tente novamente.", Toast.LENGTH_LONG).show()
                    webView.evaluateJavascript("window.onNativeBackupSaved && window.onNativeBackupSaved(false)", null)
                }
            } else {
                webView.evaluateJavascript("window.onNativeBackupSaved && window.onNativeBackupSaved(false)", null)
            }
        }
    }

    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }
}
